import { GraduationCap } from 'lucide-react';
import { Link, Outlet } from 'react-router-dom';
import { useAuthStore } from '@/lib/store';

export function Layout() {
  const { user, signOut } = useAuthStore();

  return (
    <div className="min-h-screen bg-gradient-to-b from-primary-50 to-white">
      <header className="bg-white shadow-sm">
        <nav className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 justify-between">
            <div className="flex">
              <Link to="/" className="flex items-center gap-2">
                <GraduationCap className="h-8 w-8 text-primary-600" />
                <span className="text-xl font-bold text-gray-900">CETStrom</span>
              </Link>
            </div>
            <div className="flex items-center gap-4">
              {user ? (
                <>
                  <Link
                    to="/admin/dashboard"
                    className="text-sm font-medium text-gray-700 hover:text-primary-600"
                  >
                    Dashboard
                  </Link>
                  <button
                    onClick={() => signOut()}
                    className="text-sm font-medium text-gray-700 hover:text-primary-600"
                  >
                    Sign Out
                  </button>
                </>
              ) : (
                <Link
                  to="/admin/login"
                  className="text-sm font-medium text-gray-700 hover:text-primary-600"
                >
                  Admin Login
                </Link>
              )}
            </div>
          </div>
        </nav>
      </header>
      <main>
        <Outlet />
      </main>
      <footer className="bg-white mt-auto">
        <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
          <p className="text-center text-sm text-gray-500">
            © 2024 CETStrom. Created by Rakesh Koneti. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}