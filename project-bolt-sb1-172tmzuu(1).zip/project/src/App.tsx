import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { HomePage } from './pages/home';
import { AdminLoginPage } from './pages/admin/login';
import { AdminDashboardPage } from './pages/admin/dashboard';
import { ExamPage } from './pages/exam';
import { Layout } from './components/layout';
import { CreateExamPage } from './pages/admin/create-exam';
import { ManageTestsPage } from './pages/admin/manage-tests';
import { ExamsListPage } from './pages/exams';
import { AboutPage } from './pages/about';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<HomePage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/exams" element={<ExamsListPage />} />
          <Route path="/admin/login" element={<AdminLoginPage />} />
          <Route path="/admin/dashboard" element={<AdminDashboardPage />} />
          <Route path="/admin/create-exam" element={<CreateExamPage />} />
          <Route path="/admin/manage-tests/:category" element={<ManageTestsPage />} />
          <Route path="/exam/:examId" element={<ExamPage />} />
        </Route>
      </Routes>
    </Router>
  );
}

export default App;