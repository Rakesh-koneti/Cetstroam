import { create } from 'zustand';
import { supabase } from './supabase';

interface AuthState {
  user: any | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  loading: true,
  signIn: async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    if (error) throw error;
  },
  signOut: async () => {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
    set({ user: null });
  },
}));

interface ExamState {
  exams: any[];
  loading: boolean;
  fetchExams: () => Promise<void>;
}

export const useExamStore = create<ExamState>((set) => ({
  exams: [],
  loading: false,
  fetchExams: async () => {
    set({ loading: true });
    const { data, error } = await supabase
      .from('exams')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (!error && data) {
      set({ exams: data });
    }
    set({ loading: false });
  },
}));