import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

export function CreateExamPage() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    title: '',
    category: 'daily',
    duration: 60,
    totalQuestions: 30,
    subjects: [] as string[],
    questions: [] as {
      text: string;
      options: string[];
      correctAnswer: number;
    }[],
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Implement exam creation logic with Supabase
    navigate('/admin/dashboard');
  };

  const addQuestion = () => {
    setFormData((prev) => ({
      ...prev,
      questions: [
        ...prev.questions,
        {
          text: '',
          options: ['', '', '', ''],
          correctAnswer: 0,
        },
      ],
    }));
  };

  return (
    <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-2xl font-semibold text-gray-900">Create New Exam</h1>
        <p className="mt-2 text-sm text-gray-700">
          Fill in the exam details and add questions below.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        <div className="space-y-6 bg-white p-6 rounded-lg shadow-sm">
          <div>
            <label
              htmlFor="title"
              className="block text-sm font-medium leading-6 text-gray-900"
            >
              Exam Title
            </label>
            <div className="mt-2">
              <Input
                type="text"
                id="title"
                value={formData.title}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, title: e.target.value }))
                }
                required
              />
            </div>
          </div>

          <div>
            <label
              htmlFor="category"
              className="block text-sm font-medium leading-6 text-gray-900"
            >
              Category
            </label>
            <div className="mt-2">
              <select
                id="category"
                className="block w-full rounded-md border-0 py-1.5 pl-3 pr-10 text-gray-900 ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-blue-600 sm:text-sm sm:leading-6"
                value={formData.category}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, category: e.target.value }))
                }
              >
                <option value="daily">Daily Test</option>
                <option value="weekly">Weekly Test</option>
                <option value="monthly">Monthly Test</option>
              </select>
            </div>
          </div>

          <div>
            <label
              htmlFor="duration"
              className="block text-sm font-medium leading-6 text-gray-900"
            >
              Duration (minutes)
            </label>
            <div className="mt-2">
              <Input
                type="number"
                id="duration"
                value={formData.duration}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    duration: parseInt(e.target.value),
                  }))
                }
                required
              />
            </div>
          </div>
        </div>

        <div className="space-y-6 bg-white p-6 rounded-lg shadow-sm">
          <div className="flex justify-between items-center">
            <h2 className="text-lg font-medium text-gray-900">Questions</h2>
            <Button type="button" onClick={addQuestion}>
              Add Question
            </Button>
          </div>

          {formData.questions.map((question, index) => (
            <div key={index} className="space-y-4 border-b pb-6">
              <h3 className="font-medium text-gray-900">Question {index + 1}</h3>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Question Text
                </label>
                <textarea
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  rows={3}
                  value={question.text}
                  onChange={(e) => {
                    const newQuestions = [...formData.questions];
                    newQuestions[index].text = e.target.value;
                    setFormData((prev) => ({ ...prev, questions: newQuestions }));
                  }}
                />
              </div>

              {question.options.map((option, optionIndex) => (
                <div key={optionIndex}>
                  <label className="block text-sm font-medium text-gray-700">
                    Option {optionIndex + 1}
                  </label>
                  <Input
                    type="text"
                    value={option}
                    onChange={(e) => {
                      const newQuestions = [...formData.questions];
                      newQuestions[index].options[optionIndex] = e.target.value;
                      setFormData((prev) => ({ ...prev, questions: newQuestions }));
                    }}
                  />
                </div>
              ))}

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Correct Answer
                </label>
                <select
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  value={question.correctAnswer}
                  onChange={(e) => {
                    const newQuestions = [...formData.questions];
                    newQuestions[index].correctAnswer = parseInt(e.target.value);
                    setFormData((prev) => ({ ...prev, questions: newQuestions }));
                  }}
                >
                  {question.options.map((_, optionIndex) => (
                    <option key={optionIndex} value={optionIndex}>
                      Option {optionIndex + 1}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          ))}
        </div>

        <div className="flex justify-end gap-4">
          <Button
            type="button"
            variant="outline"
            onClick={() => navigate('/admin/dashboard')}
          >
            Cancel
          </Button>
          <Button type="submit">Create Exam</Button>
        </div>
      </form>
    </div>
  );
}