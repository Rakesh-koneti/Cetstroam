import { PlusCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function AdminDashboardPage() {
  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
      <div className="sm:flex sm:items-center">
        <div className="sm:flex-auto">
          <h1 className="text-2xl font-semibold leading-6 text-gray-900">
            Admin Dashboard
          </h1>
          <p className="mt-2 text-sm text-gray-700">
            Manage exams, questions, and view analytics
          </p>
        </div>
        <div className="mt-4 sm:ml-16 sm:mt-0 sm:flex-none">
          <Button href="/admin/create-exam">
            <PlusCircle className="mr-2 h-4 w-4" />
            Create Exam
          </Button>
        </div>
      </div>

      <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        <div className="rounded-lg border border-gray-200 bg-white p-6">
          <h3 className="text-lg font-semibold text-gray-900">Daily Tests</h3>
          <p className="mt-2 text-sm text-gray-600">
            Quick practice tests for daily preparation
          </p>
          <div className="mt-4">
            <Button variant="outline" size="sm" href="/admin/manage-tests/daily">
              Manage Tests
            </Button>
          </div>
        </div>

        <div className="rounded-lg border border-gray-200 bg-white p-6">
          <h3 className="text-lg font-semibold text-gray-900">Weekly Tests</h3>
          <p className="mt-2 text-sm text-gray-600">
            Comprehensive weekly mock examinations
          </p>
          <div className="mt-4">
            <Button variant="outline" size="sm" href="/admin/manage-tests/weekly">
              Manage Tests
            </Button>
          </div>
        </div>

        <div className="rounded-lg border border-gray-200 bg-white p-6">
          <h3 className="text-lg font-semibold text-gray-900">Monthly Tests</h3>
          <p className="mt-2 text-sm text-gray-600">Full-length monthly mock exams</p>
          <div className="mt-4">
            <Button variant="outline" size="sm" href="/admin/manage-tests/monthly">
              Manage Tests
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}