import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';

export function ExamPage() {
  const { examId } = useParams();
  const navigate = useNavigate();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([]);
  const [timeRemaining, setTimeRemaining] = useState(3600); // 60 minutes in seconds

  // Placeholder exam data
  const exam = {
    title: 'Daily Practice Test - Physics',
    totalQuestions: 10,
    questions: [
      {
        id: 1,
        text: 'What is the SI unit of force?',
        options: ['Newton', 'Joule', 'Watt', 'Pascal'],
        correctAnswer: 0,
      },
      {
        id: 2,
        text: 'Which of the following is a vector quantity?',
        options: ['Mass', 'Velocity', 'Time', 'Temperature'],
        correctAnswer: 1,
      },
      // Add more questions as needed
    ],
  };

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          handleSubmit();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const handleAnswerSelect = (optionIndex: number) => {
    const newAnswers = [...selectedAnswers];
    newAnswers[currentQuestion] = optionIndex;
    setSelectedAnswers(newAnswers);
  };

  const handleSubmit = () => {
    // Calculate score
    const score = selectedAnswers.reduce((acc, answer, index) => {
      return acc + (answer === exam.questions[index].correctAnswer ? 1 : 0);
    }, 0);

    // TODO: Save results to database
    navigate(`/exam/${examId}/results`, {
      state: { score, total: exam.questions.length },
    });
  };

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      <div className="mb-8 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-gray-900">{exam.title}</h1>
        <div className="text-lg font-medium text-gray-700">
          Time Remaining: {formatTime(timeRemaining)}
        </div>
      </div>

      <div className="rounded-lg border border-gray-200 bg-white p-6">
        <div className="mb-4">
          <span className="text-sm font-medium text-gray-500">
            Question {currentQuestion + 1} of {exam.questions.length}
          </span>
        </div>

        <div className="mb-8">
          <p className="text-lg text-gray-900">{exam.questions[currentQuestion].text}</p>
        </div>

        <div className="space-y-4">
          {exam.questions[currentQuestion].options.map((option, index) => (
            <button
              key={index}
              className={`w-full rounded-lg border p-4 text-left transition-colors ${
                selectedAnswers[currentQuestion] === index
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-gray-200 hover:bg-gray-50'
              }`}
              onClick={() => handleAnswerSelect(index)}
            >
              {option}
            </button>
          ))}
        </div>

        <div className="mt-8 flex justify-between">
          <Button
            variant="outline"
            onClick={() => setCurrentQuestion(currentQuestion - 1)}
            disabled={currentQuestion === 0}
          >
            Previous
          </Button>
          {currentQuestion === exam.questions.length - 1 ? (
            <Button onClick={handleSubmit}>Submit Test</Button>
          ) : (
            <Button
              onClick={() => setCurrentQuestion(currentQuestion + 1)}
              disabled={currentQuestion === exam.questions.length - 1}
            >
              Next
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}