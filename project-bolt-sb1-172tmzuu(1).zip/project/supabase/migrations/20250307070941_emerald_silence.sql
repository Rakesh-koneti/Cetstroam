/*
  # Initial Schema Setup for CETStrom

  1. New Tables
    - `admins`
      - `id` (uuid, primary key)
      - `email` (text, unique)
      - `name` (text)
      - `created_at` (timestamp)
    
    - `exams`
      - `id` (uuid, primary key)
      - `title` (text)
      - `category` (text)
      - `duration` (integer, minutes)
      - `total_questions` (integer)
      - `created_at` (timestamp)
      - `created_by` (uuid, references admins)
    
    - `questions`
      - `id` (uuid, primary key)
      - `exam_id` (uuid, references exams)
      - `text` (text)
      - `options` (jsonb)
      - `correct_answer` (integer)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated admins
*/

-- Create admins table
CREATE TABLE IF NOT EXISTS admins (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  name text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create exams table
CREATE TABLE IF NOT EXISTS exams (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  category text NOT NULL,
  duration integer NOT NULL DEFAULT 30,
  total_questions integer NOT NULL,
  created_at timestamptz DEFAULT now(),
  created_by uuid REFERENCES admins(id)
);

-- Create questions table
CREATE TABLE IF NOT EXISTS questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  exam_id uuid REFERENCES exams(id) ON DELETE CASCADE,
  text text NOT NULL,
  options jsonb NOT NULL,
  correct_answer integer NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE admins ENABLE ROW LEVEL SECURITY;
ALTER TABLE exams ENABLE ROW LEVEL SECURITY;
ALTER TABLE questions ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Admins can read own data"
  ON admins
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Admins can read all exams"
  ON exams
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can insert exams"
  ON exams
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid()::text = created_by::text);

CREATE POLICY "Admins can update own exams"
  ON exams
  FOR UPDATE
  TO authenticated
  USING (auth.uid()::text = created_by::text);

CREATE POLICY "Admins can read all questions"
  ON questions
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Public can read published exams"
  ON exams
  FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Public can read exam questions"
  ON questions
  FOR SELECT
  TO anon
  USING (true);

-- Insert initial admin
INSERT INTO admins (email, name)
VALUES ('rakesh.koneti@cetstrom.com', 'Rakesh Koneti')
ON CONFLICT DO NOTHING;